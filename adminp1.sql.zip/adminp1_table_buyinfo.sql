
-- --------------------------------------------------------

--
-- Table structure for table `buyinfo`
--
-- Creation: May 09, 2024 at 02:21 PM
--

CREATE TABLE `buyinfo` (
  `id` int NOT NULL,
  `tracking_no` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` int NOT NULL,
  `prod_id` int NOT NULL,
  `payment_mode` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `payment_id` varchar(191) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `comments` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
