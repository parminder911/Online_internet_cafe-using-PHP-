
-- --------------------------------------------------------

--
-- Table structure for table `job_prices`
--
-- Creation: May 09, 2024 at 02:21 PM
--

CREATE TABLE `job_prices` (
  `job_prices_id` int NOT NULL,
  `job_id` int NOT NULL,
  `category_name` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
