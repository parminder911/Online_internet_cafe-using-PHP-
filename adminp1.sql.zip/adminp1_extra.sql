
--
-- Indexes for dumped tables
--

--
-- Indexes for table `buyinfo`
--
ALTER TABLE `buyinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobinfo`
--
ALTER TABLE `jobinfo`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `job_prices`
--
ALTER TABLE `job_prices`
  ADD PRIMARY KEY (`job_prices_id`),
  ADD KEY `job_price_fk` (`job_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ragister`
--
ALTER TABLE `ragister`
  ADD KEY `email_3` (`email`) USING BTREE,
  ADD KEY `email_2` (`email`) USING BTREE,
  ADD KEY `email` (`email`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buyinfo`
--
ALTER TABLE `buyinfo`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `jobinfo`
--
ALTER TABLE `jobinfo`
  MODIFY `job_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `job_prices`
--
ALTER TABLE `job_prices`
  MODIFY `job_prices_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `job_prices`
--
ALTER TABLE `job_prices`
  ADD CONSTRAINT `job_prices_ibfk_1` FOREIGN KEY (`job_id`) REFERENCES `jobinfo` (`job_id`);
