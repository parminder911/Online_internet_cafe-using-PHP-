
-- --------------------------------------------------------

--
-- Table structure for table `ragister`
--
-- Creation: May 09, 2024 at 02:21 PM
--

CREATE TABLE `ragister` (
  `email` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `role_as` tinyint NOT NULL DEFAULT '0',
  `createdat` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ragister`
--

INSERT INTO `ragister` (`email`, `password`, `role_as`, `createdat`) VALUES
('msljvej048@ipahive.org', '123', 0, '2024-03-24 08:27:53'),
('123@mail.com', '123', 0, '2024-03-24 09:01:06'),
('hudocafe1@gmail.com', '@Time007', 0, '2024-03-26 04:20:27'),
('hudocafe1@gmail.com', '@Time007', 0, '2024-03-26 04:21:02'),
('123@mail.com', '123', 0, '2024-03-26 04:26:17'),
('4430@alvisani.com', '4430', 0, '2024-03-26 04:35:56'),
('55@gmail.com', '55', 0, '2024-04-03 04:00:08'),
('33@gmail.com', '33', 1, '2024-04-09 08:13:41');
