
-- --------------------------------------------------------

--
-- Table structure for table `products`
--
-- Creation: May 09, 2024 at 02:21 PM
--

CREATE TABLE `products` (
  `id` int NOT NULL,
  `category_id` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_general_ci NOT NULL,
  `original_price` int NOT NULL,
  `selling_price` int NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint NOT NULL,
  `trending` tinyint NOT NULL,
  `meta_title` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `meta_keywords` mediumtext COLLATE utf8mb4_general_ci NOT NULL,
  `meta_description` mediumtext COLLATE utf8mb4_general_ci NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `required_documents` mediumtext COLLATE utf8mb4_general_ci NOT NULL,
  `popular` tinyint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `slug`, `description`, `original_price`, `selling_price`, `image`, `status`, `trending`, `meta_title`, `meta_keywords`, `meta_description`, `create_at`, `required_documents`, `popular`) VALUES
(35, 58, 'Resume', 'Resume', 'Resume', 50, 20, 'Resumehudocafe_1715827890.png', 0, 1, 'Resume', 'Resume', 'Resume', '2024-05-16 02:51:30', '10th certificate\r\n12th certificate\r\noptional: - course certificate , experience\r\n', 0),
(36, 57, 'Pan card APPLY/Update', 'Pancard', 'Seamless PAN Card Application: Apply hassle-free for your PAN Card with Hudocafe. Quick, reliable, and expert assistance. ', 400, 195, 'pancard_1715828174.jpeg', 0, 0, 'Pan card', 'Pan Card', 'Pan Card', '2024-05-16 02:56:14', 'Aadhaar Card\r\nPassport size photo\r\nsignature\r\nmobile no.', 0),
(37, 56, 'Dr. Ambedkar Pre-Matric and Post-Matric Scholarship', 'Post-MatricScholarship', 'Unlock educational opportunities with ease! Apply for Dr. Ambedkar Scholarships effortlessly through Hudocafe. Your gateway to hassle-free scholarship applications.', 200, 100, 'Ambedkarscholarship hudocafe_1715828336.webp', 0, 0, 'Post-MatricScholarship', 'Dr. Ambedkar Pre-Matric and Post-Matric Scholarship', 'Dr. Ambedkar Pre-Matric and Post-Matric Scholarship', '2024-05-16 02:58:56', 'Passport size photo\r\nsignature\r\nIncome certificate\r\n10th certificate\r\n12th certificate\r\nvalid email\r\nmobile no.', 0);
