
-- --------------------------------------------------------

--
-- Table structure for table `categories`
--
-- Creation: May 09, 2024 at 02:21 PM
--

CREATE TABLE `categories` (
  `id` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_general_ci NOT NULL,
  `required_documents` mediumtext COLLATE utf8mb4_general_ci NOT NULL,
  `popular` tinyint NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '0',
  `image` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `meta_title` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `meta_description` mediumtext COLLATE utf8mb4_general_ci NOT NULL,
  `meta_keywords` mediumtext COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `required_documents`, `popular`, `status`, `image`, `meta_title`, `meta_description`, `meta_keywords`, `created_at`) VALUES
(55, 'jobs', 'jobs', 'jobs', '', 0, 0, 'alljobshudocafe_1715833079.webp', 'jobs  ', 'jobs', 'jobs', '2024-05-10 02:27:57'),
(56, 'Scholarship', 'Scholarship', 'scholarship', '', 0, 0, 'Scholarshipshudocafe_1715827556.png', 'scholarship ', 'scholarship', 'scholarship', '2024-05-10 02:29:11'),
(57, 'GovernmenteServices', 'GovernmenteServices', 'Government e-Services', '', 0, 0, 'GovernmenteServices_1715827445.webp', 'Government e-Services   ', 'Government e-Services', 'Government e-Services', '2024-05-10 02:31:11'),
(58, 'Resume', 'Resume', 'Resume', '', 0, 0, 'Resumehudocafe_1715827732.png', 'Resume', 'Resume', 'Resume', '2024-05-16 02:48:52');
