
-- --------------------------------------------------------

--
-- Table structure for table `jobinfo`
--
-- Creation: May 09, 2024 at 02:21 PM
-- Last update: May 16, 2024 at 02:54 AM
--

CREATE TABLE `jobinfo` (
  `job_id` int NOT NULL,
  `category_id` int NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_general_ci NOT NULL,
  `sc` int NOT NULL,
  `gen` int NOT NULL,
  `female` int DEFAULT NULL,
  `handicap` int NOT NULL,
  `other` int NOT NULL,
  `otherbox` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `job` tinyint NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint NOT NULL,
  `trending` tinyint NOT NULL,
  `meta_title` varchar(191) COLLATE utf8mb4_general_ci NOT NULL,
  `meta_keywords` mediumtext COLLATE utf8mb4_general_ci NOT NULL,
  `meta_description` mediumtext COLLATE utf8mb4_general_ci NOT NULL,
  `popular` tinyint NOT NULL,
  `required_documents` mediumtext COLLATE utf8mb4_general_ci NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobinfo`
--

INSERT INTO `jobinfo` (`job_id`, `category_id`, `name`, `slug`, `description`, `sc`, `gen`, `female`, `handicap`, `other`, `otherbox`, `job`, `image`, `status`, `trending`, `meta_title`, `meta_keywords`, `meta_description`, `popular`, `required_documents`, `create_at`) VALUES
(13, 55, 'NDA Pune Group C Recruitment 2024', 'NDA2024', 'NDA Pune Group C Recruitment 2024', 50, 100, 0, 0, 0, '', 0, 'NDA2024posts_1715828068.webp', 0, 0, 'NDA', 'NDA2024', 'NDA2024', 0, 'Passport size photo\r\nsignature\r\nQualification certificate\r\nvalid email\r\nmobile no.', '2024-05-16 02:54:28');
