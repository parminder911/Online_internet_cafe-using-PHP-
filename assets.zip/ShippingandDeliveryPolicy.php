<?php
include ('includes/header.php');
?>
    <div class="color1">
      <h1>Shipping and Delivery Policy</h1>
    </div>
    <p><b> Last updated: 01-05-2024 </b></p>

    <div class="container">
      <div class="row">
       
        <h2>Services Available on Hudocafe</h2>
    
    <ul>
        <li>Job Form Filling</li>
        <li>Scholarship Form Fill</li>
        <li>Resume Build</li>
    </ul>
   

        <h2>Service Delivery within 1-3 working days</h2>
        
        <ul>
          <li>
              we complete our Service within 1-3 working days.
            <!--from the time of providing necessary details on WhatsApp.-->
          </li>
        </ul>

        <h2>Service Availability</h2>
              <ul>
          <li>
            We offer online form filling services exclusively within India Only.
          </li>
        </ul>

        <h2>Delivery Charges</h2>
              <ul>
          <li>
            There are no delivery charges for our online form filling services.
          </li>
        </ul>

        <h2>Tracking and Communication</h2>
       
        <ul>
          <li>
            Customers can inquire about their service status by sending us a email at <a href="mailto:Contact@hudocafe.com">Contact@hudocafe.com</a>
            message on WhatsApp [ WhatsApp number - +91 8437301521 ] or through other social media platforms where we
            are available.
          </li>
        </ul>

        <h2>Delayed Delivery</h2>
        
        <ul>
          <li>
            If your service is not delivered within 3 working days, we will <a href="https://www.hudocafe.com/assets/CancellationandRefundPolicy.html" >Refund</a> Back Customers money. 
          </li>
        </ul>

        <h2>Contact Us</h2>
        <ul>
          <li>
       
          If you have any questions or concerns about our Shipping and Delivery
          Policy, please contact us at +91 8437301521 or 
          <a href="mailto:Contact@hudocafe.com">Contact@hudocafe.com</a>.
          
             </li>
        </ul>
       
        
        
        
        
        
      </div>
    </div>
    <?php include ('includes/footer.php')  ?>
