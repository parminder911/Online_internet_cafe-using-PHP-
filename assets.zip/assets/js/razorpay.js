    // Pay Amount
    jQuery(document).ready(function ($) {
        jQuery('#PayNow').click(function (e) {
            e.preventDefault();

            var paymentOption = '';
            var billing_mobile = $('#billing_mobile').val();
            var shipping_mobile = $('#billing_mobile').val();
            var paymentOption = "netbanking";
            var payAmount = $('input[name=payOption]:checked').val(); // Get the value of the selected radio button

            var request_url = "submitpayment.php";
            var formData = {
                billing_mobile: billing_mobile,
                shipping_mobile: shipping_mobile,
                paymentOption: paymentOption,
                payAmount: payAmount,
                action: 'payOrder'
            }

            // Your AJAX code here to submit the form data


            $.ajax({
                type: 'POST',
                url: request_url,
                data: formData,
                dataType: 'json',
                encode: true,
            }).done(function (data) {

                if (data.res == 'success') {
                    var orderID = data.order_number;
                    var orderNumber = data.order_number;
                    var options = {
                        "key": data.razorpay_key, // Enter the Key ID generated from the Dashboard
                        "amount": data.userData.amount, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
                        "currency": "INR",
                        "name": "Hudocafe", //your business name
                        "description": data.userData.description,
                        "image": "https://www.Hudocafe.com/assets/img/Hudocafelogo.svg",
                        "order_id": data.userData.rpay_order_id, //This is a sample Order ID. Pass 
                        "handler": function (response) {

                            window.location.replace("payment-success.php?oid=" + orderID + "&rp_payment_id=" + response.razorpay_payment_id + "&rp_signature=" + response.razorpay_signature);

                        },
                        "modal": {
                            "ondismiss": function () {
                                window.location.replace("payment-success.php?oid=" + orderID);
                            }
                        },
                        "prefill": { //We recommend using the prefill parameter to auto-fill customer's contact information especially their phone number

                            "contact": data.userData.mobile //Provide the customer's phone number for better conversion rates 
                        },
                        "notes": {
                            "address": "HUDOCAFE"
                        },
                        "config": {
                            "display": {
                                "blocks": {
                                    "banks": {
                                        "name": 'Pay using ' + paymentOption,
                                        "instruments": [

                                            {
                                                "method": paymentOption
                                            },
                                        ],
                                    },
                                },
                                "sequence": ['block.banks'],
                                "preferences": {
                                    "show_default_blocks": true,
                                },
                            },
                        },
                        "theme": {
                            "color": "#3399cc"
                        }
                    };
                    var rzp1 = new Razorpay(options);
                    rzp1.on('payment.failed', function (response) {

                        window.location.replace("payment-failed.php?oid=" + orderID + "&reason=" + response.error.description + "&paymentid=" + response.error.metadata.payment_id);

                    });
                    rzp1.open();
                    e.preventDefault();
                }

            });
        });
    });

