function toggleTextBoxes() {

    alert("working fine");

    var checkbox = document.getElementById("jobCheckbox");
    var additionalFields = document.getElementById("additionalFields");
    
    if (checkbox.checked) {
        additionalFields.style.display = "block";
    } else {
        additionalFields.style.display = "none";
    }
}
