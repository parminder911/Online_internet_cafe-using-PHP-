<?php
include('includes/header.php');
include('functions/userfunctions.php');

if (isset($_GET['product'])) {
    $product_slug = $_GET['product'];
    $product_data = getslugActive("products", $product_slug);
    $product = mysqli_fetch_array($product_data);

    if ($product) {
?>
        <div class="bg-light py-4 ">
            <div class="container mt-3  ">
                <div class="row">
                    <div class="col-md-4">
                        <div class="shadow">
                            <img src="uploads/<?= $product['image'];  ?>" alt="product image" class="w-100">
                        </div>
                    </div>
                    <div class="col-md-8">
                        <h4 class="fw-bold"><?= $product['name'];  ?>
                            <span class="float-end text-danger "><?php if ($product['trending']) {
                                                                        echo "Trending";
                                                                    } ?> </span>
                        </h4>
                        <hr>
                        <h3>Description</h3>
                        <p><?= $product['description'];  ?></p>

                        <div class="row">
                            <div class="col-md-6">
                                <h4>Rs. <span class="text-success fw-bold "> <?= $product['selling_price'];  ?> </span> </h4>

                                <h6>M.R.P: <s class="text-danger"> <?= $product['original_price'];  ?> </s> </h6>

                            </div>
                        </div>
                        <h3>Required Documents:</h3>
                        <pre><?= $product['required_documents'];  ?></pre>


                        <fieldset class="border p-2">
                            <legend class="float-none w-auto p-2">Payment section</legend>

                        <div class="row">
                            <div class="col">
                                <div class="panel panel-default">
                                    
                                    <div class="panel-body">


                                        <div class="form-group">
                                            <label>Whatsapp Number</label>
                                            <input type="number" class="form-control" name="billing_mobile" id="billing_mobile"
                                                min-length="10" max-length="10" placeholder="Enter Whatsapp Number" required >
                                        </div>

                                        <br>
                                            <div class="form-group">
                                                <input type="radio" id="selling_price" name="payOption" value="<?= $product['selling_price']; ?>">
                                                <label for="sselling_pricec"> Service Price - <?= $product['selling_price']; ?>₹ </label>
                                            </div>
                           
                                      <br>


                                        <!-- submit button -->
                                        <button id="PayNow" class="btn btn-success btn-lg btn-block">Submit & Pay</button>

                                    </div>
                                </div>
                            </div>
                        </div>

                        </fieldset>



                    </div>
                </div>
            </div>
        </div>
<?php
    } else {
        $errorMessage = "Product NOT found";
        include('error.php');

      
    }
} else {

    $errorMessage = "Something went wrong";
    include('error.php');

    
}
include('includes/footer.php')
?>