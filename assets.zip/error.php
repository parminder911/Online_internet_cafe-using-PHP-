<div class="col-md-12 text-center  ">
    <h4 class="m-5" ><?php echo $errorMessage; ?></h4>
    <p>Please try again later or contact support for assistance.</p>
    <a href="index.php" class="btn btn-primary mb-5 ">Go to Home Page</a>
    <br>
</div>
