<?php
// session_start();
include('../functions/myfunctions.php');

// Check if the user is logged in
if (isset($_SESSION['auth']))
 {

    if (isset($_SESSION['role_as']) && $_SESSION['role_as'] == 1) {
        // User is logged in but not as admin
        redirect("../nimda/index.php", "HUDOCAFE / Not authorized");
        exit();
    }
    


} 
else {

    // User is not logged in, redirect to login page
    redirect("../login.php", "Login to continue");
    exit(); // Stop further execution

}



// If the script reaches here, it means the user is logged in as admin
// Proceed with displaying the admin panel
