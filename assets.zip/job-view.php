<?php
include ('includes/header.php');
include ('functions/userfunctions.php');

if (isset($_GET['job'])) {
    $job_slug = $_GET['job'];
    $job_data = getslugActive("jobinfo", $job_slug);
    $job = mysqli_fetch_array($job_data);

    if ($job) {
        ?>
        <div class="bg-light py-4 ">
            <div class="container mt-3  ">
                <div class="row">
                    <div class="col-md-4">
                        <div class="shadow">
                            <img src="uploads/<?= $job['image']; ?>" alt="job image" class="w-100">
                        </div>
                    </div>

                    <div class="col-md-8">
                        <h4 class="fw-bold"><?= $job['name']; ?>
                            <span class="float-end text-danger "><?php if ($job['trending']) {
                                echo "Trending";
                            } ?> </span>
                        </h4>
                        <hr>
                        <h3>Description</h3>
                        <p><?= $job['description']; ?></p>


                        <fieldset class="border p-2">
                            <legend class="float-none w-auto p-2">Price For Job</legend>
                            <div class="row">

                                <?php if (!empty($job['sc'])): ?>
                                    <div class="col-md-2">
                                        <h5>SC/ST <span class="text-success fw-bold "> <?= $job['sc']; ?> </span> </h5>
                                    </div>

                                <?php endif; ?>

                                <?php if (!empty($job['gen'])): ?>

                                    <div class="col-md-2">
                                        <h5>GEN/OBC <span class="text-success fw-bold "> <?= $job['gen']; ?> </span> </h5>
                                    </div>
                                <?php endif; ?>


                                <?php if (!empty($job['female'])): ?>
                                    <div class="col-md-2">
                                        <h5>Female <span class="text-success fw-bold"><?= $job['female']; ?></span></h5>
                                    </div>
                                <?php endif; ?>


                                <?php if (!empty($job['handicap'])): ?>

                                    <div class="col-md-2">
                                        <h5>Handicap <span class="text-success fw-bold "> <?= $job['handicap']; ?> </span> </h5>
                                    </div>
                                <?php endif; ?>

                                <?php if (!empty($job['other'])): ?>

                                    <div class="col-md-3">
                                        <h5><?= $job['otherbox']; ?></h5>
                                        <h5>
                                            <span class="text-success fw-bold "> <?= $job['other']; ?></span>
                                        </h5>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </fieldset>


                        <h3>Required Documents:</h3>
                        <pre><?= $job['required_documents']; ?></pre>


                        <fieldset class="border p-2">
                            <legend class="float-none w-auto p-2">Payment section</legend>

                        <div class="row">
                            <div class="col">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title">Payment </h4>
                                    </div>
                                    <div class="panel-body">


                                        <div class="form-group">
                                            <label>Mobile Number</label>
                                            <input type="number" class="form-control" name="billing_mobile" id="billing_mobile"
                                                min-length="10" max-length="10" placeholder="Enter Whatsapp Number" required
                                                autofocus="">
                                        </div>

                                        <?php if (!empty($job['sc'])): ?>
                                            <div class="form-group">
                                                <input type="radio" id="sc" name="payOption" value="<?= $job['sc']; ?>">
                                                <label for="sc">SC/ST - <?= $job['sc']; ?></label>
                                            </div>
                                        <?php endif; ?>

                                        <?php if (!empty($job['gen'])): ?>
                                            <div class="form-group">
                                                <input type="radio" id="gen" name="payOption" value="<?= $job['gen']; ?>">
                                                <label for="gen">GEN/OBC - <?= $job['gen']; ?></label>
                                            </div>
                                        <?php endif; ?>

                                        <?php if (!empty($job['female'])): ?>
                                            <div class="form-group">
                                                <input type="radio" id="female" name="payOption" value="<?= $job['female']; ?>">
                                                <label for="female">Female - <?= $job['female']; ?></label>
                                            </div>
                                        <?php endif; ?>

                                        <?php if (!empty($job['handicap'])): ?>
                                            <div class="form-group">
                                                <input type="radio" id="handicap" name="payOption" value="<?= $job['handicap']; ?>">
                                                <label for="handicap">Handicap - <?= $job['handicap']; ?></label>
                                            </div>
                                        <?php endif; ?>

                                        <?php if (!empty($job['other'])): ?>
                                            <div class="form-group">
                                                <input type="radio" id="other" name="payOption" value="<?= $job['other']; ?>">
                                                <label for="other"><?= $job['otherbox']; ?> - <?= $job['other']; ?></label>
                                            </div>
                                        <?php endif; ?>


                                        <!-- submit button -->
                                        <button id="PayNow" class="btn btn-success btn-lg btn-block">Submit & Pay</button>

                                    </div>
                                </div>
                            </div>
                        </div>

                        </fieldset>


                    </div>
                </div>
            </div>
        </div>

        </fieldset>




        </div>
        <!--  closed div of 8 col for discription -->


        </div>
        </div>
        </div>
        <?php
    } else {

          // Include the file with custom error message
          $errorMessage = "job NOT found";
          include('error.php');
        
        
    }
} else {

    $errorMessage = "Something went wrong";
    include('error.php');
  
}
include ('includes/footer.php')
    ?>

