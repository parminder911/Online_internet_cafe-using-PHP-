<?php


     $host = "localhost";
     $username = "hudocaf1_parminder";
     $password = "8obPh}&g#D!F";
     $database = "hudocaf1_adminp1";

    $con = mysqli_connect($host, $username, $password, $database);

    if(!$con)
    {
        die("connection failed: ".mysqli_connect_error());
    }

    // else
    // {
    //     echo "connected Sucessfully";
    // }

?>