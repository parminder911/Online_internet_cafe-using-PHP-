<?php

//  session_start();

include('config/dbcon.php');


function getAllActive($table) {   
    global $con;
    $query = "SELECT * FROM $table WHERE name != 'jobs' ";
     return  $query_run = mysqli_query($con,$query);

}
function getAllActivejobs($table) {   
    global $con;
    $query = "SELECT * FROM $table Where name = 'jobs'   ";
     return  $query_run = mysqli_query($con,$query);

}

function redirect($url , $message) 
{

    $_SESSION['message'] = $message;   
    header("Location:$url");
    exit();
}

function getIDActive($table,$id) {   
    global $con;
    $query = "SELECT * FROM $table WHERE id= '$id' AND status = '0'  ";
     return $query_run = mysqli_query($con,$query);

}

function getslugActive($table,$slug) {   
    global $con;
    $query = "SELECT * FROM $table WHERE slug= '$slug' AND status = '0' 'LIMIT 1' ";
     return  $query_run = mysqli_query($con,$query);

}
function getresumeActive($table,$slug) {   
    global $con;
    $query = "SELECT * FROM $table WHERE slug= 'Resume' AND status = '0' 'LIMIT 1' ";
     return  $query_run = mysqli_query($con,$query);

}


// function getnameActive($table,$name) {   
//     global $con;
//     $query = "SELECT * FROM $table WHERE name= '$name' AND 'LIMIT 1' ";
//      return  $query_run = mysqli_query($con,$query);

// }

function getProdBycategory($category_id)
{

    global $con;
    $query = "SELECT * FROM products WHERE category_id = '$category_id' AND status = '0' ";
     return  $query_run = mysqli_query($con,$query);


}

function getjobBycategory($category_id)
{

    global $con;
    $query = "SELECT * FROM jobinfo WHERE category_id = '$category_id' AND status = '0' ";
     return  $query_run = mysqli_query($con,$query);


}

function getAlltrending() {   
    global $con;
    $query = "SELECT * FROM products WHERE trending='1' ORDER BY id DESC LIMIT 5  ";
     return  $query_run = mysqli_query($con,$query);

}



function getAlljobs() {   
    global $con;
    $query = "SELECT * FROM categories WHERE name != 'scholarship'  ";
     return  $query_run = mysqli_query($con,$query);

}
function getAllscholarships() {   
    global $con;
    $query = "SELECT * FROM categories WHERE name != 'scholarship' ";
     return  $query_run = mysqli_query($con,$query);


}
function getProdByCategoryName($category_name)
{
    global $con;
     // Modify the SQL query to fetch the latest 5 items
     $query = "SELECT * FROM products WHERE category_id IN (SELECT id FROM categories WHERE name = '$category_name') ";

    // $query = "SELECT * FROM products WHERE category_id IN (SELECT id FROM categories WHERE name = '$category_name')   ";
    return mysqli_query($con, $query);

    

    
    //  $products = mysqli_query($con, $query);


}

function getProdByjobs($category_name)
{
    global $con;
    $query = "SELECT * FROM jobinfo WHERE category_id IN (SELECT id FROM categories WHERE name = '$category_name')   ";
    return mysqli_query($con, $query);
}







?>