<?php 
// session_start();

include ('../config/dbcon.php');
include('./myfunctions.php');

// if(isset($_POST['ragister_btn']))
// {
//     $email = mysqli_real_escape_string($con,$_POST['email'])  ;
//     $password = mysqli_real_escape_string($con,$_POST['password']);
// }

// $insert_query = "INSERT INTO ragister (email,password) VALUES ('$email','$password')";

// $insert_query_run = mysqli_query($con,$insert_query);

// if($insert_query_run)
// {
//     $_SESSION['message'] = "Ragistered sucessfully";
//      header('Location:../login.php');
// }
// else
// {
//     $_SESSION['message'] = "error in Ragistation";

// }


// for log in to user

if (isset($_POST['login_btn'])) 
{

    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $login_query = "SELECT * FROM ragister Where email='$email' AND password='$password' ";
    $login_query_run = mysqli_query($con, $login_query);

    if (mysqli_num_rows($login_query_run) > 0)
     {

        // Successful login
        $_SESSION['auth'] = true;

        // Extract user data securely
        $userdata = mysqli_fetch_array($login_query_run);        
        $useremail = $userdata['email'];
        $role_as = $userdata['role_as'];        
        
        // Store valid email in session (corrected)
        $_SESSION['auth_user'] = [
            'email' => $useremail,
        ];

        redirect("../nimda/index.php","welcome to hudocafe");


      $_SESSION['role_as'] = $role_as;

      if($role_as == 1)
      {
        redirect("../nimda/index.php"," welcom to ADMIN PENAL");

      }

      else
      {
        redirect("../index.php","welcome to hudocafe");

      }
      
    } 
    else
     {
        redirect("../login.php" , "Invalid credentials");
        
    }

}


// if (isset($_POST['login_btn']))
//  {

//     $email = mysqli_real_escape_string($con,$_POST['email']);
//     $password = mysqli_real_escape_string($con,$_POST['password']);

//     $login_query = "SELECT * FROM ragister Where email='$email' AND password='$password' ";

//     $login_query_run = mysqli_query($con,$login_query);

//     if (mysqli_num_rows($login_query_run) > 0) 
//     {

//         $_SESSION['auth'] = true;
//         $userdata = mysqli_fetch_array($login_query_run);
//         $useremail = $userdata['email'];
//         $userpassword = $userdata['password'];


//         $_SESSION['auth_user'] = [
//             'email' => $userdata,
//             'password' => $userdata

//         ];

//         $_SESSION['message'] = "logged in sucessfully";
//         header('Location:../nimda/index.php');



//     }
//     else
//     {
//         $_SESSION['message'] =  "Invalid Credentials";
//         header('Location:../login.php');
//     }

// }




?>