<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Success</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./bootstrap/cs/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title text-success">Payment Successful!</h3>
                        <p class="card-text">Thank you for your payment. Your transaction was successful.</p>
                        <div class="array-output">
                            <h5>Transaction Details:</h5>
                            <p><strong>Order ID:</strong> <?php echo $_GET['oid']; ?></p>
                            <p><strong>Razorpay Payment ID:</strong> <?php echo $_GET['rp_payment_id']; ?></p>
                            <p><strong>Razorpay Signature:</strong> <?php echo $_GET['rp_signature']; ?></p>
                        </div>
                        <p class="card-text">Redirecting to WhatsApp in 6 seconds...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- JavaScript for redirecting to WhatsApp after 6 seconds -->
    <script>
        // Delayed redirect function
        function redirectToWhatsApp() {
            // Redirect URL to WhatsApp
            var whatsappURL = "https://wa.me/919780013863?text=Hello";
            // Delayed redirect after 6 seconds
            setTimeout(function() {
                window.location.href = whatsappURL;
            }, 6000); // 6000 milliseconds = 6 seconds
        }

        // Call the redirect function when the page loads
        window.onload = redirectToWhatsApp;
    </script>
</body>
</html>
