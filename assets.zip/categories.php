<?php include ('includes/header.php');
include ('functions/userfunctions.php');
?>

<!-- for banners  -->

<div class="py-3 bg-primary ">
    <div class="container ">
        <h6 class="text-white">
            <a class="text-white" href="index.php">
                home/
            </a>
            <a class="text-white" href="categories.php">
                services/
            </a>


    </div>
</div>

<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4>Our Services </h4>
                <hr>
                <div class="row">
                    <?php
                    $categories = getAllActive("categories");

                    if (mysqli_num_rows($categories) > 0) {

                        foreach ($categories as $item) {
                            ?>
                            <div class="col-md-4 mb-3">
                                <a href="products.php?category=<?= $item['slug']; ?>">
                                    <div class="card shadow ">
                                        <div class="card-body">
                                            <h4 class="text-center">
                                                <img src="uploads/<?= $item['image']; ?>" alt="<?= $item['slug']; ?>"
                                                    class="w-100 img-thumbnail  " style="height: 23rem;">
                                                <?= $item['slug']; ?>

                                            </h4>
                                        </div>
                                    </div>

                                </a>

                            </div>
                            <?php
                        }
                    } else {
                        $errorMessage = "no data available";
                        include ('error.php');


                    }

                    ?>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="container">
    <div class="row">
        <div class="col-md-12">


            <div class="row">
                <?php
                $categories = getAllActivejobs("categories");

                if (mysqli_num_rows($categories) > 0) {

                    foreach ($categories as $item) {
                        ?>
                        <div class="col-md-4 mb-3">
                            <a href="job.php?category=<?= $item['slug']; ?>">
                                <div class="card shadow ">
                                    <div class="card-body">
                                        <h4 class="text-center">
                                            <img src="uploads/<?= $item['image']; ?>" alt="<?= $item['slug']; ?>"
                                                class="w-100 img-thumbnail  " style="height: 23rem;">
                                            <?= $item['slug']; ?>

                                        </h4>
                                    </div>
                                </div>

                            </a>

                        </div>
                        <?php
                    }
                } else {

                    $errorMessage = "no data available";
                    include ('error.php');
                }

                ?>
            </div>
        </div>
    </div>
</div>



<?php include ('includes/footer.php') ?>