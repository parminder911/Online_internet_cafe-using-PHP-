<?php include('includes/header.php');

 include('functions/myfunctions.php');

//   if already log in then not able to access login page  


if (isset($_SESSION['auth']))
 {

  redirect("./nimda/index.php", "Already logged in");
  
}

?>
 



<div class="py-5">
  <div class="container">
    <div class="row justify-content-center ">
     

      <div class="col-6">
        <div class="card">
          <div class="card-header">
            <h4>LOGIN</h4>
          </div>
          <div class="card-body">

            <form action="./functions/authcode.php" method="post"  >
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email address</label>
                <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
               
              </div>
              
              <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input type="password" name="password" class="form-control" id="exampleInputPassword1">
              </div>
              
              <button type="submit" name="login_btn" class="btn btn-primary">Log in</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php') ?>