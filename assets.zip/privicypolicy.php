<?php
include ('includes/header.php');
?>
<div class="color1">
  <h1>Privacy Policy</h1>
</div>
<p><b> Last updated: 01-05-2024 </b></p>

<div class="container">
  <div class="row">


    <h2>Services Available on Hudocafe</h2>
    <ul>
      <li>Job Form Filling</li>
      <li>Scholarship Form Fill</li>
      <li>Resume Build</li>
    </ul>

    <h2>SECTION 1 - WHAT DO WE DO WITH YOUR INFORMATION?</h2>
    <p>When you purchase something from our website <a href="https://www.hudocafe.com/"> [https://www.hudocafe.com/]</a>
      , as part of the buying and selling process, we collect the personal information you give us such as your name,
      contact number, and email address.</p>

    <h2>SECTION 2 - CONSENT</h2>
    <p><strong>How do you get my consent?</strong></p>
    <p>When you provide us with personal information to complete a transaction, verify your credit card, place an order,
      or arrange for a delivery, we imply that you consent to our collecting it and using it for that specific reason
      only.</p>
    <p><strong>How do I withdraw my consent?</strong></p>
    <p>If after you opt-in, you change your mind, you may withdraw your consent for us to contact you, for the continued
      collection, use, or disclosure of your information, at any time, by contacting us at <a
        href="mailto:contact@hudocafe.com">Contact@hudocafe.com</a>.</p>

    <h2>SECTION 3 - DISCLOSURE</h2>
    <p>We may disclose your personal information if we are required by law to do so or if you violate our Terms of
      Service.</p>

    <h2>SECTION 4 - PAYMENT</h2>
    <p>We use Razorpay for processing payments. Razorpay does not store your card data on their servers. The data is
      encrypted through the Payment Card Industry Data Security Standard (PCI-DSS) when processing payment. For more
      insight, you may also want to read the terms and conditions of Razorpay on <a
        href="https://razorpay.com">https://razorpay.com</a>.</p>

    <h2>SECTION 5 - THIRD-PARTY SERVICES</h2>
    <p>Certain third-party service providers, such as payment gateways and other payment transaction processors, have
      their own privacy policies in respect to the information we are required to provide to them for your
      purchase-related transactions.</p>

    <h2>SECTION 6 - SECURITY</h2>
    <p>To protect your personal information, we take reasonable precautions and follow industry best practices to make
      sure it is not inappropriately lost, misused, accessed, disclosed, altered, or destroyed.</p>

    <h2>SECTION 7 - COOKIES</h2>
    <p>We don’t use cookies to maintain the session of your user.</p>

    <h2>SECTION 8 - AGE OF CONSENT</h2>
    <p>By using this site, you represent that you are at least the age of majority in your state or province of
      residence, or that you are the age of majority in your state or province of residence and you have given us your
      consent to allow any of your minor dependents to use this site.</p>

    <h2>SECTION 9 - CHANGES TO THIS PRIVACY POLICY</h2>
    <p>We reserve the right to modify this privacy policy at any time, so please review it frequently. Changes and
      clarifications will take effect immediately upon their posting on the website.</p>

    <h2>QUESTIONS AND CONTACT INFORMATION</h2>
    <p>If you would like to: access, correct, amend or delete any personal information we have about you, register a
      complaint, or simply want more information contact our Privacy Compliance Officer at <a
        href="mailto:contact@hudocafe.com">Contact@hudocafe.com</a>.</p>



    <p>
      Hudocafe may change this policy from time to time by updating this
      page. You should check this page from time to time to ensure that you
      are happy with any changes.
    </p>
  </div>
</div>


<?php
include ('includes/footer.php')
  ?>