<?php
include('includes/header.php');
include('functions/userfunctions.php');


if (isset($_GET['category']))
 {
    $category_slug = $_GET['category'];
    $category_data = getslugActive("categories", $category_slug);
    $category = mysqli_fetch_array($category_data);
    if ($category) 
    {
        $cid = $category['id'];
?>
        <!-- for banners  -->
        <div class="py-3 bg-primary ">
            <div class="container ">
                <h6 class="text-white">
                    <a class="text-white" href="index.php">
                        home/
                    </a>
                    <a class="text-white" href="categories.php">
                        services/
                    </a>
                    <?= $category['name']; ?>
                </h6>
            </div>
        </div>
        <div class="py-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h4><?= $category['name']; ?></h4>
                        <hr>
                        <div class="row">
                            <?php
                            $products = getjobBycategory($cid);

                            if (mysqli_num_rows($products) > 0) {
                                foreach ($products as $item) {
                            ?>
                                    <div class="col-md-4 mb-3">
                                        <a href="job-view.php?job=<?= $item['slug']; ?>">
                                            <div class="card shadow ">
                                                <div class=" card-body card-body-job ">
                                                    <img src="uploads/<?= $item['image']; ?>"  class="  img-thumbnail  " style="   height: 26rem;    width: 20rem;  " >
                                                    <h4 class="text-center"><?= $item['name']; ?></h4>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                <?php
                                }
                            } 
                            else {
                                ?>
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <button>Go to homepage</button>
                                        </div>
                                    </div>
                                </div>
                            <?php

$errorMessage = "no data available";
include('error.php');

                              
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php
    } else {
        $errorMessage = "Something went wrong";
        include('error.php');

               
    }
}
 else {
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <a href="index.php">
                <button class="btn btn-secondary">Go to homepage</button></a>
            </div>
        </div>
    </div>
<?php
    $errorMessage = "Something went wrong";
    include('error.php');
}
include('includes/footer.php')
?>