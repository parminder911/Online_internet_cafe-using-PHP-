<?php

include ('includes/header.php');
include ('includes/slider.php');
include ('functions/userfunctions.php');

?>
<br>
<div class="py-3">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <h4 class="d-inline-block">Trending Services</h4>
                <strong> <a href="categories.php">more</a> </strong>

                <hr>
                <div class="owl-carousel">
                    <?php
                    $trendingproducts = getAlltrending();
                    if (mysqli_num_rows($trendingproducts) > 0) {
                        foreach ($trendingproducts as $item) {
                            ?>
                            <div class="item">
                                <a href="products-view.php?product=<?= $item['slug']; ?>">
                                    <div class="card shadow ">
                                        <div class="card-body  ">
                                            <img src="uploads/<?= $item['image']; ?>" class="img-thumbnail img-85 ">
                                            <h6 class="text-center"><?= $item['name']; ?></h6>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- jobs carousel  -->
<div class="py-3">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4 class="d-inline-block">Avaliable Jobs</h4> <strong> <a href="job.php?category=Jobs">more</a>
                </strong>
                <hr>
                <div class="owl-carousel">
                    <?php
                    $products = getProdByjobs('jobs');
                    if (mysqli_num_rows($products) > 0) {
                        foreach ($products as $item) {
                            ?>
                            <div class="item">
                                <a href="products-view.php?product=<?= $item['slug']; ?>">
                                    <div class="card shadow ">
                                        <div class="card-body">
                                            <img src="uploads/<?= $item['image']; ?>" class="img-thumbnail img-85 ">
                                            <h4 class="text-center"><?= $item['name']; ?></h4>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <?php
                        }
                    } else {
                        // Include the file when no jobs are available
                        include ('error.php');
                    }
                    ?>
                </div>
            </div>

        </div>
    </div>
</div>



<!-- govern metnt e services  -->

<div class="py-3">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4 class="d-inline-block">Government e-Services</h4>
                <strong> <a href="products.php?category=Government e-Services">more</a> </strong>
                <hr>
                <div class="owl-carousel">
                    <?php
                    $products = getProdByCategoryName('GovernmenteServices');
                    if (mysqli_num_rows($products) > 0) {
                        foreach ($products as $item) {
                            ?>
                            <div class="item">
                                <a href="products-view.php?product=<?= $item['slug']; ?>">
                                    <div class="card shadow ">
                                        <div class="card-body">
                                            <img src="uploads/<?= $item['image']; ?>" class="img-thumbnail img-85 ">
                                            <h4 class="text-center"><?= $item['name']; ?></h4>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <?php
                        }
                    } else {
                      echo "No Service available.";
                    }
                    ?>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="py-3">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4 class="d-inline-block">Avaliable Scholarships</h4>
                <strong> <a href="products.php?category=Scholarships">more</a> </strong>
                <hr>
                <div class="owl-carousel">
                    <?php
                    $products = getProdByCategoryName('Scholarship');
                    if (mysqli_num_rows($products) > 0) {
                        foreach ($products as $item) {
                            ?>
                            <div class="item">
                                <a href="products-view.php?product=<?= $item['slug']; ?>">
                                    <div class="card shadow ">
                                        <div class="card-body">
                                            <img src="uploads/<?= $item['image']; ?>" class="img-thumbnail img-85 ">
                                            <h4 class="text-center"><?= $item['name']; ?></h4>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <?php
                        }
                    } else {
                        echo "No scholarships available.";
                    }
                    ?>
                </div>
            </div>

        </div>
    </div>
</div>



<div class="py-5 bg-dark ">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h4 class="text-white">Hudocafe</h4>
                <div class="underline"> </div>
                <br>
                <div class="d-flex flex-column ">

                    <a href="www.hudocafe.com" class="text-white"> <i class="fa fa-angle-right"> </i> Home </a>

                    <a href="./aboutus.Php  " class="text-white"> <i class="fa fa-angle-right"> </i> About us </a>

                    <a href="./contactus.Php" class="text-white"> <i class="fa fa-angle-right"> </i> contact us </a>

                    <a href="categories.php" class="text-white"> <i class="fa fa-angle-right"> </i> Services</a>

                    <a href="job.php?category=Jobs" class="text-white"> <i class="fa fa-angle-right"> </i> jobs </a>
                </div>
            </div>


            <div class="col-md-6  ">

                <div class="d-flex flex-column ">

                    <ul class="mt-3 ml-0 ">
                        <li class="">
                            <a class="text-white" href="./privicypolicy.php">Privacy Policy</a>
                        </li>
                        <li>
                            <a class="text-white" href="./termsandcondition.php"> Terms & Conditions</a>
                        </li>
                        <li>
                            <a class="text-white" href="./CancellationandRefundPolicy.php">Cancellation and Refund</a>
                        </li>
                        <li>
                            <a class="text-white" href="./ShippingandDeliveryPolicy.php">Shipping and Delivery</a>
                        </li>
                    </ul>
                </div>



                <div class="container  ">
                    <div class="row">
                        <div class="col">


                            <h4 class="text-white"> Social Media </h4>

                            <a href="https://www.facebook.com/profile.php?id=100089492627717" target="_blank">
                                <i class="fa fa-facebook color70"></i>
                            </a>
                            <a href="https://twitter.com/hudocafe" target="_blank">
                                <i class="color70 fa fa-twitter  "></i>
                            </a>
                            <a href="https://www.instagram.com/hudocafe/" target="_blank">
                                <i class="fa fa-instagram color70"></i>
                            </a>
                            <a href="https://www.linkedin.com/in/hudo-cafe-b88b83262">
                                <i class=" color70 fa fa-linkedin " target="_blank"></i>
                            </a>
                            <a href="https://youtube.com/@hudocafe" target="_blank">
                                <i class=" color70 fa fa-youtube color70 "></i>
                            </a>
                            <a href="https://t.me/Hudocafe">
                                <i class=" color70  fa fa-telegram " target="_blank"></i>
                            </a>




                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<?php include ('includes/whatsapp.php') ?>

<?php include ('includes/footer.php') ?>

<script>
    $(document).ready(function () {
        $('.owl-carousel').owlCarousel({
            stagePadding: 50,
            loop: true,
            margin: 10,
            nav: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 3
                },
                1000: {
                    items: 4
                }
            }
        })
    });
</script>