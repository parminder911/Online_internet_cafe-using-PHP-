<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./bootstrap/cs/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title text-danger">Payment Failed!</h3>
                        <p class="card-text">We're sorry, but your payment was not successful.</p>
                        <div class="array-output">
                            <h5>Error Details:</h5>
                            <p><strong>Error Reason:</strong> <?php echo isset($_GET['reason']) ? $_GET['reason'] : 'Unknown'; ?></p>
                            <p><strong>Razorpay Payment ID:</strong> <?php echo isset($_GET['paymentid']) ? $_GET['paymentid'] : 'N/A'; ?></p>
                        </div>
                        <a href="https://www.hudocafe.com" class="btn btn-primary mt-3">Go to Home Page</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

