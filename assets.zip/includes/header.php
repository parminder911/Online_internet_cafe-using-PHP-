<?php
// Include database connection file
include_once './config/dbcon.php';  ?>

<?php
// Function to fetch meta information from the database
function fetchMetaInfo($table, $slug) {
    global $con;
    $query = "SELECT * FROM $table WHERE slug = '$slug'";
    $result = mysqli_query($con, $query);
    if(mysqli_num_rows($result) > 0) {
        return mysqli_fetch_assoc($result);
    }
    return false;
}

// Retrieve the slug from the URL
if(isset($_GET['product'])) {
    $product_slug = $_GET['product'];

    // Fetch meta information for products
    $product_meta = fetchMetaInfo('products', $product_slug);

    if($product_meta) {
        // Set meta tags for products
        $meta_title = $product_meta['meta_title'];
        $meta_description = $product_meta['meta_description'];
        $meta_keywords = $product_meta['meta_keywords'];
    } else {
        // Product not found, set default meta tags
        $meta_title = "Hudocafe";
        $meta_description = "Hudocafe";
        $meta_keywords = "Hudocafe";
    }
} elseif(isset($_GET['job'])) {
    $job_slug = $_GET['job'];

    // Fetch meta information for job
    $job_meta = fetchMetaInfo('jobinfo', $job_slug);

    if($job_meta) {
        // Set meta tags for job
        $meta_title = $job_meta['meta_title'];
        $meta_description = $job_meta['meta_description'];
        $meta_keywords = $job_meta['meta_keywords'];
    } else {
        // Job not found, set default meta tags
        $meta_title = "Hudocafe";
        $meta_description = "Hudocafe";
        $meta_keywords = "Hudocafe";
    }
} else {
    // Neither product nor job slug provided, set default meta tags
    $meta_title = "Hudocafe";
    $meta_description = "Hudocafe";
    $meta_keywords = "Hudocafe";
}
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $meta_title; ?> | online internet cafe | Hudocafe</title>
<meta name="description" content=" <?php echo $meta_description; ?> Simplify Form Filling with Hudocafe - Your Online Internet Cafe. Fill forms from the comfort of your home. Hassle-free, easy, and secure. Say goodbye to long queues and hello to convenience! ">
<meta name="keywords" content="<?php echo $meta_keywords; ?>Hudocafe | online internet Cafe ">




 <!-- bootstrap css -->
 <link rel="stylesheet" href="./bootstrap/cs/bootstrap.min.css">
   <!-- bootstrap js -->
   <script src="./bootstrap/js/bootstrap.bundle.min.js"></script>
   <script src="./bootstrap/js/jquerymin.js"></script>
   <!-- owl carousel for slide  -->
   <link rel="stylesheet" href="./assets/css/owl.carousel.min.css">
   <link rel="stylesheet" href="./assets/css/owl.theme.default.min.css">
   <!-- font-awesome -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <!-- google fonts -->
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=Ojuju:wght@200..800&family=Playfair+Display:ital,wght@0,400..900;1,400..900&family=Reddit+Mono:wght@200..900&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="./assets/css/custom.css">
    
   <!-- for razorpay PG -->
      <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
   <script src="./assets/js/razorpay.js"></script>


   <!-- //for SEO Prospective -->

   <link rel="icon" type="image/x-icon" href="./assets/img/favicon.ico" />

     <!-- Google tag (gtag.js) -->
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-X2P7YNVRYE"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-X2P7YNVRYE');
</script>

  <!-- schema.org markup -->
  <script type="application/ld+json">
  {
      "@context": "https://schema.org",
      "@type": "InternetCafe",
      "name": "Hudocafe",
      "image": "https://www.hudocafe.com/assets/img/hudocafelogo.svg",
      "url": "https://www.hudocafe.com/",
      "address": {
          "@type": "Chandigarh",
          "addressCountry": "IN"
      },
      "sameAs": [
          "https://www.facebook.com/profile.php?id=100089492627717",
          "https://www.instagram.com/hudocafe/",
          "https://www.youtube.com/@hudocafe?reload=9",
          "https://whatsapp.com/channel/0029VaJU757C1Fu6qfnNcx3o"
      ]
  }
</script>


  <!--open graph code start -->
  <meta property="og:title" content=online internet cafe | Hudocafe>
  <meta property="og:site_name" content=Hudocafe>
  <meta property="og:url" content=https://www.hudocafe.com />
  <meta property="og:description" content=Simplify Form Filling with Hudocafe - Your Online Internet Cafe. Fill forms from the comfort of your home. Hassle-free, easy, and secure. Say goodbye to long queues in offline cafe...>
  <meta property="og:type" content=website>
  <meta property="og:image" content=https://www.hudocafe.com/assets/img/hudocafelogo.svg>

  <!--for twitter open graph-->
  <meta name="twitter:card" content="summary">
  <meta name="twitter:site" content="@Hudocafe">
  <meta name="twitter:title" content="online internet cafe | Hudocafe ">
  <meta name="twitter:description"
    content="Simplify Form Filling with Hudocafe - Your Online Internet Cafe. Fill forms from the comfort of your home. Hassle-free, easy, and secure. Say goodbye to long queues and hello to convenience!">
  <meta name="twitter:image" content="	https://www.hudocafe.com/assets/img/hudocafelogo.svg">
  <!--open graph code end-->
 



</head>
<body>
<?php include('navbar.php')  ?>












