<div class="py-2  " style="background-color: #70bb43;">
    <div class="text-center">
        <p class="mb-0 text-black "> All rights reserved. copyright @ <a href="" class="text-black">Hudocafe</a> 2023
        </p>
    </div>
</div> 
</body>

<script src="./assets/js/owl.carousel.min.js"></script>
<script src="./assets/js/job.js"></script>

</html>