<?php
include ('includes/header.php');
?>
<div class="color1">
  <h1>Refunds/Cancellations Policy</h1>
</div>
<p><b> Last updated: 01-05-2024 </b></p>
<div class="container">
  <div class="row">
    <h2>Services Available on Hudocafe</h2>

    <ul>
      <li>Job Form Filling</li>
      <li>Scholarship Form Fill</li>
      <li>Resume Build</li>
    </ul>
    <p>At Hudocafe, we prioritize customer satisfaction and aim to provide exceptional service.
      While we strive to ensure your complete satisfaction, we understand that there may be instances
      where you need to cancel a service request or request a refund. Please review our comprehensive Refund Policy
      below:</p>

    <h4>Returns</h4>

    <ul>
      <li>
        To be eligible for a return, your form must not be started to fill by us or the service not used. </li>

      <li> If you made the wrong payment, for example, if you chose category SC but you belong to the GEN category, we
        will refund you. </li>

      <li> If your form is not in the initial state or has not started,
        and if we start providing you with the service but you are ineligible for it,
        for example, if the job qualification requires graduation but you are only 12th pass, then we will refund your
        money.

      </li>
    </ul>

    <p>Our refund policy lasts for 7 days. If 7 days have passed since your purchase, unfortunately,
      we cannot offer you a refund or exchange.</p>

    <p>Several types of goods are exempt from being returned, including service refunds like form filling.
      Additionally, since we do not deal with physical products, refunds are not applicable in all cases.</p>
    <h4>Refunds (if applicable)</h4>
    <p>If your return meets the eligibility criteria mentioned above, and if we have not yet started the process of
      filling out your form, you may request a refund. Refunds will be processed within 5-6 working days, and the full
      amount will be refunded to your Bank Account.</p>

    <h4>Exclusions</h4>
    <p>Please note that if we have already commenced processing your service request and you are deemed eligible, the
      service will be completed, and a refund will not be applicable.</p>

    <h4>Contact Us</h4>
    <p>For any inquiries regarding cancellations or refund requests, please contact our customer support team at <a
        href="mailto:contact@hudocafe.com">Contact@hudocafe.com</a>. We are here to address your concerns and ensure
      your satisfaction with our services.</p>

  </div>
</div>

<?php include ('includes/footer.php') ?>