<?php
include('../middleware/adminmiddleware.php');
include('includes/header.php');
?>

<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Jobs</h5>
                    </div>
                    <div class="card-body" id="jobinfo_table">
                        <table class="table table-bordered table-striped ">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Image</th>
                                    <th>visibility</th>
                                    <th>edit</th>
                                    <th>Delete</th>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $jobinfo = getAll("jobinfo");
                                if (mysqli_num_rows($jobinfo) > 0) {
                                    foreach ($jobinfo as $item) {
                                ?>
                                        <tr>
                                            <td>
                                                <?= $item['job_id'] ?>
                                            </td>
                                            <td>
                                                <?= $item['name'] ?>
                                            </td>
                                            <td>
                                                 <img src="../uploads/<?= $item['image'] ?> " alt="<?= $item['job_id'] ?>" width="50px" height="50px"> </td>
                                            <td>
                                                <?= $item['status'] == '0' ? "Visible" : "Hidden" ?>
                                            </td>
                                            <td> 
                                                <a href="edit-job.php?job_id=<?= $item['job_id'] ?>" class="btn btn-sm btn-primary ">Edit</a>

                                            </td>
                                            <td>
                                                <button type="button"  class="delete_job_btn btn btn-danger" value="<?= $item['job_id']  ?> ">Delete</button>

                                            </td>
                                        </tr>
                                <?php
                                    }
                                } else {
                                    echo "no record found";
                                }

                                ?>



                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>