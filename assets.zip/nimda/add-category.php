<?php
// session_start();
include('../middleware/adminmiddleware.php');
include('includes/header.php');

?>

<!-- to show   -->
<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>cartgory add</h4>
                    </div>
                    <div class="card-body">
                        <form action="code.php" method="POST" enctype="multipart/form-data">

                            <div class="row">
                                <div class="col-md-6">

                                    <label for="">name</label>
                                    <input type="text" name="name" class="form-control">

                                </div>

                                <div class="col-md-6">

                                    <label for="">slug</label>
                                    <input type="text" name="slug" class="form-control">

                                </div>

                                <div class="col-md-12">
                                    <label for="">Description</label>
                                    <textarea rows="3" name="description" id="" class="form-control"></textarea>
                                </div>
                                <div class="col-md-12">
                                    <label for="">Required Documents</label>
                                    <textarea name="required_documents" rows="4" cols="5" class="form-control" name="required_documents" id="" cols="30" rows="10"></textarea>
                                </div>
                                <div class="col-md-12">
                                    <label for="">Upload image</label>
                                    <input class="form-control" type="file" name="image">

                                </div>

                                <div class="col-md-6">
                                    <label for="">meta Title</label>
                                    <input name="meta_title" type="text" class="form-control">

                                </div>

                                <div class="col-md-3 mt-4 ">
                                    <label for="">status</label>
                                    <input type="checkbox" name="status">
                                </div>

                                <div class="col-md-3 mt-4">
                                    <label for="">popular</label>
                                    <input type="checkbox" name="popular">
                                </div>

                                <div class="col-md-12">
                                    <label for="">meta_description</label>
                                    <textarea class="form-control" name="meta_description" id="" rows="3"></textarea>
                                </div>
                                <div class="col-md-12">
                                    <label for="">meta_keywords</label>

                                    <textarea class="form-control" name="meta_keywords" id="" rows="3"></textarea>
                                </div>

                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary" name="add_category_btn">Save</button>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>










<?php include('./includes/footer.php'); ?>