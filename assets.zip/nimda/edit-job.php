<?php
include('../middleware/adminmiddleware.php');
include('includes/header.php');
include('../config/dbcon.php');
?>
<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php
                if (isset($_GET['job_id'])) {

                    $job_id = $_GET['job_id'];

                    $jobs = getByjobID("jobinfo", $job_id);

                    if (mysqli_num_rows($jobs) > 0) {

                        $data = mysqli_fetch_array($jobs);
                ?>
                        <div class="card">
                            <div class="card-header">
                                <h4> EDIT 2 jobinfo </h4>
                            </div>
                            <div class="card-body">
                                <form action="code.php" method="POST" enctype="multipart/form-data">

                                    <div class="row">
                                        <div class="col-md-6">
                                            <label for="">Select Category</label>
                                            <select name="category_id" class="form-select">
                                                <option selected>select Category</option>

                                                <?php

                                                $categories = getAll("categories");

                                                if (mysqli_num_rows($categories) > 0) {

                                                    foreach ($categories as $item) {
                                                ?>

                                                        <option value="<?= $item['id'] ?>" <?= $data['category_id'] == $item['id'] ? 'selected' : ''     ?>><?= $item['name'] ?></option>

                                                <?php
                                                    }
                                                } else {
                                                    echo "no category avaliable";
                                                }

                                                ?>

                                            </select>

                                        </div>

                                        <div class="col-md-6">

                                            <input type="hidden" name="jobsid" value="<?= $data['job_id']; ?>">

                                            <label for="">name</label>
                                            <input type="text" value="<?= $data['name']; ?>" name="name" class="form-control mb-2  ">

                                        </div>
                                        <div class="col-md-6">

                                            <label for="">slug</label>
                                            <input type="text" value="<?= $data['slug']; ?>" name="slug" class="form-control mb-2 ">

                                        </div>

                                        <div class="col-md-6">
                                            <label for="">meta Title</label>
                                            <input name="meta_title" value="<?= $data['meta_title']; ?>" type="text" class="form-control mb-2 ">

                                        </div>

                                        <div class="col-md-12">
                                            <label for="">Description</label>
                                            <textarea rows="3" name="description" id="" class="form-control mb-2 "><?= $data['description'] ?></textarea>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="">Required Documents</label>
                                            <textarea name="required_documents" rows="4" class="form-control mb-2 "><?= $data['required_documents'] ?></textarea>

                                        </div>
                                        <fieldset class="border p-2">
                                            <legend class="float-none w-auto p-2">Price For Job</legend>

                                            <div class="row">


                                                <div class="col-md-3">
                                                    <label for="">SC/St</label>
                                                    <input type="text" value="<?= $data['sc']; ?>" name="sc" class="form-control mb-2 ">
                                                </div>
                                                <div class="col-md-3">
                                                    <label for="">GEN/OBC</label>
                                                    <input type="text" value="<?= $data['gen']; ?>" name="gen" class="form-control mb-2 ">
                                                </div>
                                                <div class="col-md-3">
                                                    <label for="">female</label>
                                                    <input type="text" value="<?= $data['female']; ?>" name="female" class="form-control mb-2 ">
                                                </div>
                                                <div class="col-md-3">
                                                    <label for="">handicap</label>
                                                    <input type="text" value="<?= $data['handicap']; ?>" name="handicap" class="form-control mb-2 ">
                                                </div>
                                               

                                        <div class="col-md-3">
                                            <label for="other">Other</label>
                                            <input type="text" value="<?= $data['other']; ?>" id="other" name="other" class="form-control mb-2">
                                        </div>
                                        <div id="specificCategory" style="display: none;" class="col-md-3">
                                            <label for="specific">Specific Category</label>
                                            <input type="text" value="<?= $data['otherbox']; ?>"  id="specific" name="otherbox" class="form-control mb-2">
                                        </div>



                                                <div class="col-md-2">

                                                <label for="">Job</label>
                                                <input type="checkbox" name="job" <?= $data['job'] == '0' ? '' : 'checked' ?> >

                                                        </div>



                                            </div>

                                        </fieldset>

                                        <div class="col-md-12">
                                            <label for="">Upload image</label>
                                            <input type="hidden" name="old_image" value="<?= $data['image']; ?>">
                                            <input class="form-control mb-2 " type="file" name="image">

                                            <label class="mb-0">current image</label>
                                            <img src="../uploads/<?= $data['image']; ?>" alt="<?= $data['name']; ?>" height="150px" width="150px">

                                        </div>

                                        <div class="row">

                                            <div class="col-md-4">

                                                <label for="">status</label>
                                                <input type="checkbox" name="status" <?= $data['status'] == '0' ? '' : 'checked' ?> >


                                            </div>

                                            <div class="col-md-4">
                                                <label for="">popular </label>
                                                <input type="checkbox" <?= $data['popular'] == '0' ? '' : 'checked' ?> name="popular">
                                            </div>

                                            <div class="col-md-4">

                                                <label for="">trending </label>
                                                <input type="checkbox" <?= $data['trending'] == '0' ? '' : 'checked' ?> name="trending">


                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <label for="">meta_description</label>
                                            <textarea class="form-control mb-2 " name="meta_description" id="" rows="5"><?= $data['meta_description'] ?></textarea>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="">meta_keywords</label>

                                            <textarea class="form-control mb-2 " name="meta_keywords" id="" rows="3"><?= $data['meta_keywords'] ?></textarea>
                                        </div>

                                        <div class="col-md-12">
                                            <button type="submit" class="btn btn-primary" name="update_job_btn">Update</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                <?php

                    } 
                    else
                     {
                        echo " PRODUCT not found for given id ";
                    }
                } 
                else
                 {
                    echo " id missing from URL  ";
                }
                ?>
            </div>
        </div>
    </div>
</div>










<?php include('./includes/footer.php'); ?>



<script>
    document.addEventListener("DOMContentLoaded", function() {
        var otherInput = document.getElementById("other");
        var specificCategoryDiv = document.getElementById("specificCategory");

        otherInput.addEventListener("input", function() {
            if (otherInput.value.trim().length > 0) {
                specificCategoryDiv.style.display = "block";
            } else {
                specificCategoryDiv.style.display = "none";
            }
        });
    });
</script>