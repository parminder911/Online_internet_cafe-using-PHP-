<?php
include ('../config/dbcon.php');
include ('../functions/myfunctions.php');
if (isset($_POST['add_category_btn'])) {
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $meta_title = $_POST['meta_title'];
    $description = $_POST['description'];
    $required_documents = $_POST['required_documents'];
    $meta_description = $_POST['meta_description'];
    $meta_keywords = $_POST['meta_keywords'];
    $popular = isset($_POST['popular']) ? '1' : '0';
    $status = isset($_POST['status']) ? '1' : '0';

    $image = $_FILES['image']['name'];

    $path = "../uploads";
    // Get the extension of the uploaded file
    $image_ext = pathinfo($image, PATHINFO_EXTENSION);
    // Get the filename without the extension
    $image_name_without_ext = pathinfo($image, PATHINFO_FILENAME);
    // Concatenate the timestamp with the filename and then add the extension back
    $filename = $image_name_without_ext . '_' . time() . '.' . $image_ext;

    move_uploaded_file($_FILES['image']['tmp_name'], $path . '/' . $filename);

    $cate_Query = "INSERT INTO categories (name,slug,meta_title,description,required_documents,meta_description,meta_keywords,popular,status,image) VALUES ('$name', '$slug', '$meta_title','$description','$required_documents','$meta_description','$meta_keywords','$popular','$status','$filename')";

    $cate_Query_run = mysqli_query($con, $cate_Query);
    if ($cate_Query_run) {
        move_uploaded_file($_FILES['image']['temp_name'], $path . '/' . $filename);

        redirect("./add-category.php", "category added sucessfully");
    } else {
        redirect("./add-category.php", "Something went wrong");
    }
} else if (isset($_POST['update_category_btn'])) {
    $category_id = $_POST['category_id'];
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $meta_title = $_POST['meta_title'];
    $description = $_POST['description'];
    $required_documents = $_POST['required_documents'];
    $meta_description = $_POST['meta_description'];
    $meta_keywords = $_POST['meta_keywords'];
    $popular = isset($_POST['popular']) ? '1' : '0';
    $status = isset($_POST['status']) ? '1' : '0';

    // Get the category ID and sanitize it
    $category_id = mysqli_real_escape_string($con, $_POST['category_id']);

    // Fetch the old image details
    $category_query = "SELECT * FROM categories WHERE id='$category_id'";
    $category_query_run = mysqli_query($con, $category_query);
    $category_data = mysqli_fetch_array($category_query_run);
    $old_image = $category_data['image'];

    // Process the updated image, if provided
    $new_image = $_FILES['image']['name'];
    $path = "../uploads";

    if ($new_image != "") {
        // Append timestamp to the image name
        $image_name_without_ext = pathinfo($new_image, PATHINFO_FILENAME);
        $image_ext = pathinfo($new_image, PATHINFO_EXTENSION);
        $update_filename = $image_name_without_ext . '_' . time() . '.' . $image_ext;
        // Move and rename the uploaded file
        move_uploaded_file($_FILES['image']['tmp_name'], $path . '/' . $update_filename);
        // Delete the old image file if it exists and it's different from the new filename
        if ($old_image != $new_image && file_exists($path . '/' . $old_image)) {
            unlink($path . '/' . $old_image);
        }
    } else {
        // If no new image is provided, keep the existing image
        $update_filename = $old_image;
    }

    // Update the category information
    $update_query = "UPDATE categories SET name='$name', slug='$slug', meta_title='$meta_title', description='$description', required_documents='$required_documents', meta_description='$meta_description', meta_keywords='$meta_keywords', status='$status', popular='$popular', image='$update_filename' WHERE id='$category_id'";

    $update_query_run = mysqli_query($con, $update_query);

    if ($update_query_run) {
        redirect("edit-category.php?id=$category_id", "Category updated successfully");
    } else {
        redirect("edit-category.php?id=$category_id", "Something went wrong");
    }
} else if (isset($_POST['delete_category_btn'])) {

    $category_id = mysqli_real_escape_string($con, $_POST['category_id']);

    //for fetch image detail for delete
    $category_query = "SELECT * FROM categories WHERE id='$category_id' ";
    $category_query_run = mysqli_query($con, $category_query);
    $category_data = mysqli_fetch_array($category_query_run);
    $image = $category_data['image'];
    $delete_query = "DELETE FROM categories WHERE id='$category_id'  ";
    $delete_query_run = mysqli_query($con, $delete_query);
    if ($delete_query_run) {
        if (file_exists("../uploads/" . $image)) {
            unlink("../uploads/" . $image);
        }

        echo 200;

        //redirect("./category.php", "Category deleted sucessfully");
    } else {
        echo 500;
        //redirect("./category.php", "Something went wrong");
    }
} else if (isset($_POST['add_Product_btn'])) {

    $category_id = $_POST['category_id'];
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $meta_title = $_POST['meta_title'];
    $description = $_POST['description'];
    $required_documents = $_POST['required_documents'];
    $original_price = $_POST['original_price'];
    $selling_price = $_POST['selling_price'];
    $status = isset($_POST['status']) ? '1' : '0';
    $popular = isset($_POST['popular']) ? '1' : '0';
    $trending = isset($_POST['trending']) ? '1' : '0';
    $meta_keywords = $_POST['meta_keywords'];
    $meta_description = $_POST['meta_description'];


    $image = $_FILES['image']['name'];
    $path = "../uploads";

    $image_ext = pathinfo($image, PATHINFO_EXTENSION);
    $image_name_without_ext = pathinfo($image, PATHINFO_FILENAME);
    $filename = $image_name_without_ext . '_' . time() . '.' . $image_ext;
    move_uploaded_file($_FILES['image']['tmp_name'], $path . '/' . $filename);


    $product_query = "INSERT INTO products (category_id, name, slug, meta_title, description, required_documents, original_price, selling_price, status, popular, trending, meta_keywords, meta_description,image ) VALUES ('$category_id', '$name', '$slug', '$meta_title', '$description', '$required_documents', '$original_price', '$selling_price', '$status', '$popular', '$trending', '$meta_keywords', '$meta_description', '$filename')";

    $product_query_run = mysqli_query($con, $product_query);

    if ($product_query_run) {

        move_uploaded_file($_FILES['image']['tmp_name'], $path . '/' . $filename);
        redirect("./add-Products.php", "product added successfully");
    } else {
        redirect("./add-Products.php", "something went wrong !product Not added ");
    }
} else if (isset($_POST['update_Product_btn'])) {

    $product_id = $_POST['product_id'];
    $category_id = $_POST['category_id'];
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $meta_title = $_POST['meta_title'];
    $description = $_POST['description'];
    $required_documents = $_POST['required_documents'];
    $original_price = $_POST['original_price'];
    $selling_price = $_POST['selling_price'];
    $status = isset($_POST['status']) ? '1' : '0';
    $popular = isset($_POST['popular']) ? '1' : '0';
    $trending = isset($_POST['trending']) ? '1' : '0';
    $meta_keywords = $_POST['meta_keywords'];
    $meta_description = $_POST['meta_description'];

    $old_image = $_POST['old_image'];

    // Get the category ID and sanitize it
    $product_id = mysqli_real_escape_string($con, $_POST['product_id']);
    // Fetch the old image details
    $category_query = "SELECT * FROM products WHERE id='$product_id'";
    $category_query_run = mysqli_query($con, $category_query);
    $category_data = mysqli_fetch_array($category_query_run);
    $old_image = $category_data['image'];
    // Process the updated image, if provided
    $new_image = $_FILES['image']['name'];
    $path = "../uploads";
    if ($new_image != "") {
        // Append timestamp to the image name
        $image_name_without_ext = pathinfo($new_image, PATHINFO_FILENAME);
        $image_ext = pathinfo($new_image, PATHINFO_EXTENSION);
        $update_filename = $image_name_without_ext . '_' . time() . '.' . $image_ext;
        // Move and rename the uploaded file
        move_uploaded_file($_FILES['image']['tmp_name'], $path . '/' . $update_filename);
        // Delete the old image file if it exists and it's different from the new filename
        if ($old_image != $new_image && file_exists($path . '/' . $old_image)) {
            unlink($path . '/' . $old_image);
        }
    } else {
        // If no new image is provided, keep the existing image
        $update_filename = $old_image;
    }

    $update_product_query = "UPDATE products SET name='$name', slug='$slug', meta_title='$meta_title', description='$description', required_documents='$required_documents', original_price='$original_price', selling_price='$selling_price', status='$status', popular='$popular', trending='$trending', meta_keywords='$meta_keywords', meta_description='$meta_description',image='$update_filename' WHERE id='$product_id' ";



    $update_product_query_run = mysqli_query($con, $update_product_query);

    if ($update_product_query_run) {

        redirect("./edit-product.php?id=$product_id", "PRODUCT updated successfully");
    } else {


        redirect("./edit-product.php?id=$product_id", "Something Went Wrong");
    }
} else if (isset($_POST['delete_product_btn'])) {

    $product_id = mysqli_real_escape_string($con, $_POST['product_id']);

    //for fetch image detail for delete
    $product_query = "SELECT * FROM products WHERE id='$product_id' ";
    $product_query_run = mysqli_query($con, $product_query);
    $product_data = mysqli_fetch_array($product_query_run);

    $image = $product_data['image'];

    $delete_query = "DELETE FROM products WHERE id='$product_id'  ";

    $delete_query_run = mysqli_query($con, $delete_query);

    if ($delete_query_run) {

        if (file_exists("../uploads/" . $image)) {
            unlink("../uploads/" . $image);
        }

        // redirect("./product.php", "product deleted sucessfully");
        echo 200;
    } else {

        redirect("./product.php", "Something went wrong");
        echo 500;
    }
}
// for job info add update and delete
else if (isset($_POST['add_job_btn'])) {

    $category_id = $_POST['category_id'];
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $meta_title = $_POST['meta_title'];
    $description = $_POST['description'];
    $sc = $_POST['sc'];
    $gen = $_POST['gen'];
    $female = $_POST['female'];
    $handicap = $_POST['handicap'];
    $other = $_POST['other'];
    $otherbox = $_POST['otherbox'];
    $job = isset($_POST['job']) ? '1' : '0';
    $required_documents = $_POST['required_documents'];
    $status = isset($_POST['status']) ? '1' : '0';
    $popular = isset($_POST['popular']) ? '1' : '0';
    $trending = isset($_POST['trending']) ? '1' : '0';
    $meta_keywords = $_POST['meta_keywords'];
    $meta_description = $_POST['meta_description'];


    $image = $_FILES['image']['name'];
    $path = "../uploads";

    $image_ext = pathinfo($image, PATHINFO_EXTENSION);
    $image_name_without_ext = pathinfo($image, PATHINFO_FILENAME);
    $filename = $image_name_without_ext . '_' . time() . '.' . $image_ext;
    move_uploaded_file($_FILES['image']['tmp_name'], $path . '/' . $filename);


    $job_query = "INSERT INTO jobinfo (category_id, name, slug, meta_title, description, required_documents, sc , gen , female , handicap , other, otherbox, job , status, popular, trending, meta_keywords, meta_description, image ) VALUES ('$category_id', '$name', '$slug', '$meta_title', '$description', '$required_documents', '$sc', '$gen', '$female', '$handicap', '$other', '$otherbox' ,'$job', '$status', '$popular', '$trending', '$meta_keywords', '$meta_description', '$filename')";

    $job_query_run = mysqli_query($con, $job_query);

    if ($job_query_run) {

        move_uploaded_file($_FILES['image']['tmp_name'], $path . '/' . $filename);
        redirect("./add-job.php", "Job added successfully");
    } else {
        redirect("./add-job.php", "something went wrong !Job Not added ");
    }
} else if (isset($_POST['update_job_btn'])) {
    // Fetch form data
    $jobsid = $_POST['jobsid'];
    $category_id = $_POST['category_id'];
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $meta_title = $_POST['meta_title'];
    $description = $_POST['description'];
    $required_documents = $_POST['required_documents'];
    $sc = $_POST['sc'];
    $gen = $_POST['gen'];
    $female = $_POST['female'];
    $handicap = $_POST['handicap'];
    $other = $_POST['other'];
    $otherbox = $_POST['otherbox'];
    $job = isset($_POST['job']) ? '1' : '0';
    $status = isset($_POST['status']) ? '1' : '0';
    $popular = isset($_POST['popular']) ? '1' : '0';
    $trending = isset($_POST['trending']) ? '1' : '0';
    $meta_keywords = $_POST['meta_keywords'];
    $meta_description = $_POST['meta_description'];

    // Image handling
    $path = "../uploads";
    $new_image = $_FILES['image']['name'];
    $old_image = $_POST['old_image'];
    $update_filename = $old_image; // Default to old image name

    if (!empty($new_image)) {
        // Process new image
        $image_name_without_ext = pathinfo($new_image, PATHINFO_FILENAME);
        $image_ext = pathinfo($new_image, PATHINFO_EXTENSION);
        $update_filename = $image_name_without_ext . '_' . time() . '.' . $image_ext;
        move_uploaded_file($_FILES['image']['tmp_name'], $path . '/' . $update_filename);
        // Delete old image if it exists and is different from the new one
        if ($old_image != $new_image && file_exists($path . '/' . $old_image)) {
            unlink($path . '/' . $old_image);
        }
    }

    // Update query
    $update_job_query = "UPDATE jobinfo SET name='$name', slug='$slug', meta_title='$meta_title', description='$description', required_documents='$required_documents', sc='$sc', gen='$gen', female='$female', handicap='$handicap', other='$other', otherbox = '$otherbox', job='$job', status='$status', popular='$popular', trending='$trending', meta_keywords='$meta_keywords', meta_description='$meta_description', image='$update_filename', category_id='$category_id' WHERE job_id='$jobsid' ";

    // Execute query
    $update_job_query_run = mysqli_query($con, $update_job_query);

    // Check if query was successful
    if ($update_job_query_run) {
        redirect("./edit-job.php?job_id=$jobsid", "Job updated successfully");
    } else {
        redirect("./edit-job.php?job_id=$jobsid", "Something went wrong while updating the job");
    }
} else if (isset($_POST['delete_job_btn'])) {

    $jobsid = mysqli_real_escape_string($con, $_POST['job_id']);

    //for fetch image detail for delete
    $job_query = "SELECT * FROM jobinfo WHERE job_id='$jobsid' ";
    $job_query_run = mysqli_query($con, $job_query);
    $job_data = mysqli_fetch_array($job_query_run);

    $image = $job_data['image'];

    $delete_query = "DELETE FROM jobinfo WHERE job_id='$jobsid'  ";

    $delete_query_run = mysqli_query($con, $delete_query);

    if ($delete_query_run) {

        if (file_exists("../uploads/" . $image)) {
            unlink("../uploads/" . $image);
        }
        // redirect("job.php", "Something went wrong");

        echo 200;
    } else {

        // redirect("./job.php", "Something went wrong");
        echo 500;
    }
} else {

    header('Location:../index.php');
}
