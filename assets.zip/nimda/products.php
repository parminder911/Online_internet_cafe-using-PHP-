<?php
include('../middleware/adminmiddleware.php');
include('includes/header.php');
?>

<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5>PRODUCTS</h5>
                    </div>
                    <div class="card-body" id="products_table">
                        <table class="table table-bordered table-striped ">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Image</th>
                                    <th>visibility</th>
                                    <th>edit</th>
                                    <th>Delete</th>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $products = getAll("products");
                                if (mysqli_num_rows($products) > 0) {
                                    foreach ($products as $item) {
                                ?>
                                        <tr>
                                            <td>
                                                <?= $item['id'] ?>
                                            </td>
                                            <td>
                                                <?= $item['name'] ?>
                                            </td>
                                            <td>
                                                 <img src="../uploads/<?= $item['image'] ?> " alt="<?= $item['id'] ?>" width="50px" height="50px"> </td>
                                            <td>
                                                <?= $item['status'] == '0' ? "Visible" : "Hidden" ?>
                                            </td>
                                            <td> 
                                                <a href="edit-product.php?id=<?= $item['id'] ?>" class="btn btn-sm btn-primary ">Edit</a>

                                            </td>
                                            <td>
                                                <button type="button" name="delete_product_btn" class="btn btn-danger delete_product_btn " value="<?= $item['id']  ?> ">Delete</button>

                                            </td>
                                        </tr>
                                <?php
                                    }
                                } else {
                                    echo "no record found";
                                }

                                ?>



                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>