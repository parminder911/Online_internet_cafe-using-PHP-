<?php
// session_start();
include('../middleware/adminmiddleware.php');
include ('includes/header.php');


?>


<!-- to edit saved data   -->

<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <?php

                if (isset($_GET['id'])) {
                    $id = $_GET['id'];
                    $category = getByID("categories", $id);
                    if (mysqli_num_rows($category) > 0) {
                        $data = mysqli_fetch_array($category);

                        ?>
                        <div class="card">
                            <div class="card-header">
                                <h4>Edit Category</h4>
                            </div>
                            <div class="card-body">
                                <form action="code.php" method="POST" enctype="multipart/form-data">

                                    <div class="row">
                                        <div class="col-md-6">

                                            <input type="hidden" name="category_id" value="<?= $data['id'] ?>">

                                            <label>name</label>
                                            <input type="text" name="name" class="form-control" value="<?= $data['name'] ?>">

                                        </div>
                                        <div class="col-md-6">

                                            <label for="">slug</label>
                                            <input type="text" name="slug" value="<?= $data['slug'] ?>" class="form-control">

                                        </div>

                                        <div class="col-md-12">
                                            <label for="">Description</label>
                                            <textarea rows="3" name="description" id=""
                                                class="form-control"><?= $data['description'] ?></textarea>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="">Required Documents</label>
                                            <textarea name="required_documents" rows="4" cols="5" class="form-control"
                                                name="required_documents" id="" cols="30"
                                                rows="10"><?= $data['required_documents'] ?></textarea>
                                        </div>

                                        <div class="col-md-12">
                                            <label for="">Upload image</label>
                                            <input class="form-control" type="file" name="image">

                                            <label for="">Current image</label>
                                            <input type="hidden" name="old_image" value="<?= $data['image'] ?> ">

                                            <img src="../uploads/<?= $data['image'] ?>" height="100" width="150"
                                                alt="<?= $data['name'] ?>">

                                        </div>

                                        <div class="col-md-6">
                                            <label for="">meta Title</label>
                                            <input name="meta_title" type="text" class="form-control"
                                                value="<?= $data['meta_title'] ?> ">

                                        </div>



                                        <div class="col-md-3 mt-4 ">
                                            <label for="">status</label>
                                            <input type="checkbox" <?= $data['status'] ? "checked" : "" ?> name="status">
                                        </div>

                                        <div class="col-md-3 mt-4">
                                            <label for="">popular</label>
                                            <input type="checkbox" <?= $data['popular'] ? "checked" : "" ?> name="popular">
                                        </div>


                                        <div class="col-md-12">
                                            <label for="">meta_description</label>
                                            <textarea class="form-control" name="meta_description" id="" cols="30"
                                                rows="10"><?= $data['meta_description'] ?></textarea>
                                        </div>

                                        <div class="col-md-12">
                                            <label for="">meta_keywords</label>
                                            <textarea class="form-control" name="meta_keywords" id=""
                                                rows="3"><?= $data['meta_keywords'] ?></textarea>
                                        </div>



                                        <div class="col-md-12">
                                            <button type="submit" class="btn btn-primary"
                                                name="update_category_btn">Update</button>
                                        </div>



                                    </div>
                                </form>


                            </div>
                        </div>
                    </div>

                    <?php

                    } else {
                        echo "category not found";
                    }
                } else {
                    echo "Id missing/ issue occur";
                }

                ?>

        </div>
    </div>
</div>










<?php include ('./includes/footer.php'); ?>