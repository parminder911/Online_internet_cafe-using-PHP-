<?php
// session_start();
include('../middleware/adminmiddleware.php');
include('includes/header.php');
include('../config/dbcon.php');

?>



<!-- to show   -->

<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4> add Products </h4>
                    </div>
                    <div class="card-body">
                        <form action="code.php" method="POST" enctype="multipart/form-data">

                            <div class="row">
                                <div class="col-md-6">
                                    <label for="">Select Category</label>
                                    <select name="category_id" class="form-select">
                                        <option selected>select Category</option>
                                        <?php
                                        $categories = getAll("categories");
                                        if (mysqli_num_rows($categories) > 0) {
                                            foreach ($categories as $item) {
                                        ?>
                                                <option value="<?= $item['id'] ?>"><?= $item['name'] ?></option>
                                        <?php
                                            }
                                        } else {
                                            echo "no category avaliable";
                                        }
                                        ?>
                                    </select>
                                </div>



                                <div class="col-md-6">

                                    <label for="">name</label>
                                    <input type="text" name="name" class="form-control mb-2  ">

                                </div>
                                <div class="col-md-6">

                                    <label for="">slug</label>
                                    <input type="text" name="slug" class="form-control mb-2 ">

                                </div>


                                <div class="col-md-6">
                                    <label for="">meta Title</label>
                                    <input name="meta_title" type="text" class="form-control mb-2 ">

                                </div>

                                <div class="col-md-12">
                                    <label for="">Description</label>
                                    <textarea rows="3" name="description" id="" class="form-control mb-2 "></textarea>
                                </div>
                                <div class="col-md-12">
                                    <label for="">Required Documents</label>
                                    <textarea name="required_documents" rows="4" class="form-control mb-2 "></textarea>

                                </div>

                        
                                <div class="col-md-6">
                                    <label for="">orignal Price</label>
                                    <input type="text" name="original_price" class="form-control mb-2 ">
                                </div>

                                <div class="col-md-6">
                                    <label for="">Selling Price</label>
                                    <input type="text" name="selling_price" class="form-control mb-2 ">
                                </div>


                                <div class="col-md-12">
                                    <label for="">Upload image</label>
                                    <input class="form-control mb-2 " type="file" name="image">
                                </div>


                                <div class="row">

                                    <div class="col-md-4">

                                        <label for="">status</label>
                                        <input type="checkbox" name="status">


                                    </div>

                                    <div class="col-md-4">
                                        <label for="">popular </label>
                                        <input type="checkbox" name="popular">
                                    </div>

                                    <div class="col-md-4">

                                        <label for="">trending</label>
                                        <input type="checkbox" name="trending">
                                    </div>

                                </div>



                                <div class="col-md-12">
                                    <label for="">meta_description</label>
                                    <textarea class="form-control mb-2 " name="meta_description" id="" rows="5"></textarea>
                                </div>
                                <div class="col-md-12">
                                    <label for="">meta_keywords</label>

                                    <textarea class="form-control mb-2 " name="meta_keywords" id="" rows="3"></textarea>
                                </div>

                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary" name="add_Product_btn">Save</button>
                                </div>



                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


