$(document).ready(function () {

    $(document).on('click', '.delete_product_btn', function(e) {

    // $('.delete_product_btn').click(function (e) 
    // {
        e.preventDefault();

        var id = $(this).val();

      //  alert(id);


        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this Product!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete)
             {
                $.ajax({

                    method:"POST",
                        url: "code.php",
                    data:{
                        'product_id':id,
                        'delete_product_btn':true
                   },  
                   sucess: function(response){

                    // console.log(response) ;                 

                    if(response == 200)
                    {
                        
                        swal("Sucessfully!", "product deleted", "success");
                        location.reload();
                        $("#products_table").load(location.href + " #products_table");



                    }
                    else if(response == 500)
                    {
                        swal("error!", "something wrong / product not deleted", "error");
                    }

                   }
                
                });
         
            } 
            // else {
            //   swal("Your Product is safe!");
            // }
          });



    });



    $(document).on('click', '.delete_category_btn', function(e) {


    // });   

    // $('.delete_category_btn').click(function (e) 
    // {


        e.preventDefault();

        var id = $(this).val();

      //  alert(id);


        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this Product!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete)
             {
                $.ajax({

                    method:"POST",
                        url: "code.php",
                    data:{
                        'category_id':id,
                        'delete_category_btn':true
                   },  
                   sucess: function(response){

                    // console.log(response) ;                 

                    if(response == 200)
                    {
                        
                        swal("Sucessfully!", "category deleted", "success");

                        $("#category_table").load(location.href + " #category_table");
                        location.reload();


                    }
                    else if(response == 500)
                    {
                        swal("error!", "something wrong / product not deleted", "error");
                    }

                   }
                
                });
         
            } 
            // else {
            //   swal("Your Product is safe!");
            // }
          });



    });

//for delete job from job list


    $(document).on('click', '.delete_job_btn', function(e) {

        // $('.delete_product_btn').click(function (e) 
        // {
            e.preventDefault();
    
            var job_id = $(this).val();
    
          //  alert(id);
    
    
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this Product!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
              })
              .then((willDelete) => {
                if (willDelete)
                 {
                    $.ajax({
    
                        method:"POST",
                            url: "code.php",
                        data:{
                            'job_id':job_id,
                            'delete_job_btn':true
                       },  
                       sucess: function(response){
    
                        // console.log(response) ;                 
    
                        if(response == 200)
                        {
                            
                            swal("Sucessfully!", "job deleted", "success");
                            
    
                            $("#jobinfo_table").load(location.href + " #jobinfo_table");
    
                            location.reload();
    
                        }
                        else if(response == 500)
                        {
                            swal("error!", "something wrong / Job not deleted", "error");
                        }
    
                       }
                    
                    });
             
                } 
                // else {
                //   swal("Your Product is safe!");
                // }
              });
    
    
    
        });



});


