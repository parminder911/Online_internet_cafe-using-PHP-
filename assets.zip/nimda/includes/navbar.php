<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="./index.php">Home</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./add-category.php">add category</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./category.php">all categories</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./add-Products.php">Add Services</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./products.php">All Services</a>
        </li>


        <li class="nav-item">
          <a class="nav-link" href="./add-job.php">Add Jobs</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./job.php"> Jobs list </a>
        </li>

        <!-- for logot and username show -->


        <?php

        if (isset($_SESSION['auth']) && $_SESSION['auth'] === true) {
          $_SESSION['auth_user']['email'];
        ?>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <?php
              // Assuming $_SESSION['auth_user']['email'] is an array
              echo htmlspecialchars($_SESSION['auth_user']['email']);
              ?>
            </a>

            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href=".././categories.php">Collection</a></li>
              <li><a class="dropdown-item" href="#">Another action</a></li>
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" href="./includes/logout.php">Logout</a></li>
            </ul>
          </li>
        <?php
        } else {
        ?>
          <li class="nav-item">
            <a href="./login.php" class="nav-link disabled">login</a>
          </li>

        <?php
        }
        ?>



      </ul>


      <!-- <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
       -->

    </div>
  </div>
</nav>