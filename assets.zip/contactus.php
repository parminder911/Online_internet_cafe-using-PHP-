<?php
include ('includes/header.php');
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center">Contact Us</h1>
            <p>
                <b> Have questions? Shoot us an Email.</b> Have a question for us, or
                feedback if anyone have any doubt or queary about Hudo cafe then they
                can reach on us with following details
            </p>
            <br>
            <div class="form-container">
                <form id="Form" method="post" action="#">
                    <h2>Contact us form</h2>
                    <div>
                        <label for="name">Name</label>
                        <input type="text" name="nm" id="name" class="form-control" required />
                    </div>
                    <div>
                        <label for="Email">Email</label>
                        <input type="email" name="em" id="Email" class="form-control" required />
                    </div>
                    <div>
                        <label for="message">Message</label>
                        <textarea class="form-control" id="message" name="msg" rows="4" required></textarea>
                    </div>

                    <br>
                    <input class="btn btn-primary" type="submit" value="Submit" class="btn" name="register" />

                </form>
            </div>
        </div>
    </div>
    <br />
</div>
</div>
</div>

<div class="container">
    <div class="row">
        <div class="col">
            <li class="m-auto w-auto">
                <b> contact@hudocafe.com</b>
            </li>
            <li class="m-auto w-auto">
                <b>+91 8437301521</b>
            </li>
        </div>
    </div>
</div>


<?php include ('includes/footer.php')    ?>